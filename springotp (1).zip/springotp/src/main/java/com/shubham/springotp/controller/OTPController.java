package com.shubham.springotp.controller;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shubham.springotp.entity.OTPEntity;
import com.shubham.springotp.service.OTPEmailService;
import com.shubham.springotp.service.OTPServiceImpl;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@CrossOrigin
@RestController
@EnableSwagger2
public class OTPController {

	@Autowired 
	private OTPServiceImpl otpServiceImpl;
	
	@Autowired
	private OTPEmailService otpEmailService;

	@PostMapping("/generateOTP")
	public ResponseEntity<?> generateOTP(@RequestParam("emailId") String emailId, @RequestParam(value = "userId", defaultValue = "1") String userId,@RequestParam("channelName") String channelName) throws MessagingException {
		
		OTPEntity otp=otpServiceImpl.generateOTP(emailId,channelName,Integer.parseInt(userId));
		if(otp == null) {
			return new ResponseEntity<String>("Cannot regenerate OTP before 60 seconds", HttpStatus.BAD_REQUEST);
		}
		String messageotp= String.valueOf(otp.getOtp());
		
		otpEmailService.sendOtpMessage(emailId , "OTP Verification",messageotp );
		return new ResponseEntity<OTPEntity>(otp, HttpStatus.OK);
		
	}

	@GetMapping("/validateOTP")
	public String validateOTP(OTPEntity otpEntity) {
		return otpServiceImpl.validateOTP(otpEntity);
	}

}
