package com.shubham.springotp.service;

import com.shubham.springotp.entity.OTPEntity;

public interface OTPService {
	
	public OTPEntity generateOTP(String emailId,String channelName, int userId);
	public String validateOTP(OTPEntity Otpentity);

}
