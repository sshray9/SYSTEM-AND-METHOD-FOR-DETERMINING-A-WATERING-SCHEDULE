package com.shubham.springotp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOTPApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringOTPApplication.class, args);	
	}
	

}
	