package com.shubham.springotp.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.shubham.springotp.entity.OTPEntity;

@Repository
public interface OTPDao extends MongoRepository<OTPEntity, String> {

}
