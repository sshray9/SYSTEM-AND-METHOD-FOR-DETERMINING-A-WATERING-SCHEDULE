package com.shubham.springotp.entity;

import org.springframework.data.mongodb.core.mapping.Document;


@Document
public class OTPEntity {

	@org.springframework.data.annotation.Id
	private String emailId;
	
	private int userId;
	private String channelName;
	
	private Long creationTime;
	
	public Long getCreationTime() {
		return creationTime;
	}


	public void setCreationTime(Long creationTime) {
		this.creationTime = creationTime;
	}


	public int getUserId() {
		return userId;
	}


	@Override
	public String toString() {
		return "OTPEntity [emailId=" + emailId + ", userId=" + userId + ", channelName=" + channelName + ", otp=" + otp
				+ "]";
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getChannelName() {
		return channelName;
	}


	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}



	private int otp;
	
	public OTPEntity() {
		// TODO Auto-generated constructor stub
	}


	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	

	public OTPEntity(int orderId, String emailId, int otp) {
		super();

		this.emailId = emailId;
		this.otp = otp;
	}
	
	
}
