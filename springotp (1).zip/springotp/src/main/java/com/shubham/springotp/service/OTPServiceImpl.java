package com.shubham.springotp.service;

import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.shubham.springotp.dao.OTPDao;
import com.shubham.springotp.entity.OTPEntity;

@Service
@PropertySource("classpath:application.properties")
public class OTPServiceImpl implements OTPService {

	@Autowired
	private OTPDao Otpdao;

	private Logger logger = LoggerFactory.getLogger(OTPServiceImpl.class);

	// @Autowired
//	private Environment environment;

	private static final Long EXPIRE_MINS = 120000L;
	private static final Long Regenerate_After = 60000L;
	// private long expire_mins =
	// Long.parseLong(environment.getProperty("otpexpiretime"));

	@Override
	public OTPEntity generateOTP(String emailId, String channelName, int userId) {
		OTPEntity entity = new OTPEntity();
		Random random = new Random();
	
		int OtpGenerate = random.nextInt(900000) + 100000;
		
		logger.info("going to find the user in the MONGO DB");
		
		if (Otpdao.existsById(emailId)) {
			System.out.println(emailId);
			logger.info("Found an existing user for the id:- " + emailId);
			entity = Otpdao.findById(emailId).get();
			logger.info("Creation time of previous OTP for the user:- " + entity.getCreationTime());
			logger.info("Current time:- " + System.currentTimeMillis() + ", tregenerate after:- " + Regenerate_After + ", difference:- " + (System.currentTimeMillis() - entity.getCreationTime()));
			if (System.currentTimeMillis() - entity.getCreationTime() > Regenerate_After) {
				
				entity.setOtp(OtpGenerate);
				entity.setCreationTime(System.currentTimeMillis());
				Otpdao.save(entity);
			} else {
				return null;
			}
		} else {
			entity.setOtp(OtpGenerate);
			entity.setEmailId(emailId);
			entity.setUserId(userId);
			entity.setChannelName(channelName);
			entity.setCreationTime(System.currentTimeMillis());

			Otpdao.save(entity);
		}

		String otp = String.valueOf(OtpGenerate);
		logger.info(otp);
		return entity;
	}

	@Override
	public String validateOTP(OTPEntity otpEntity) {
		List<OTPEntity> data = Otpdao.findAll();

		OTPEntity entity2 = null;
		
		long res = 0;
		
		try {
			entity2 = Otpdao.findById(otpEntity.getEmailId()).get();
			res = System.currentTimeMillis() - entity2.getCreationTime();
			logger.info("User with id:- " + otpEntity.getEmailId() + " found in the repository");
			logger.info("Creation of OTP time for the incoming user:- " + otpEntity.getCreationTime());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		String status = "";
		boolean flag = false;

		for (OTPEntity iteratedEntity : data) {
			if (iteratedEntity.getEmailId().equals(otpEntity.getEmailId())) {
				flag = true;
				if (iteratedEntity.getOtp() == otpEntity.getOtp() && res < EXPIRE_MINS) {
					status = "OTP is Valid!!!";
				} else if (res > EXPIRE_MINS) {
					status = "OTP expired";
					
				} else {
					status = "OTP is Invalid!!! Please Retry";
				}
			}
		}

		if (!flag) {
			status = "User does not exist";
		}
		logger.info(status);
		return status;
	}

}
