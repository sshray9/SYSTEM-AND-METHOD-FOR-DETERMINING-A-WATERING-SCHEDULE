package com.shubham.springotp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.shubham.springotp.entity.OTPEntity;

class OTPEntityTest {

	@Autowired
	OTPEntity otpEntity;

	public OTPEntity TestSuite() {
		return new OTPEntity();
	}

	@Test
	void testGetCreationTime() {
		Long time = 0L;
		otpEntity = null;
		otpEntity = TestSuite();
		time = otpEntity.getCreationTime();
	}

	@Test
	void testSetCreationTime() {
		Long time= 0L;
	    otpEntity =null;
	     otpEntity = TestSuite();
	     otpEntity.setCreationTime(time);
	}

	@Test
	void testGetUserId() {
		Integer id = 0;
		otpEntity = null;
		otpEntity = TestSuite();
		id = otpEntity.getUserId();
	}

//	@Test
//	void testToString() {
//		fail("Not yet implemented");
//	}

	@Test
	void testSetUserId() {
		Integer id= 0;
	    otpEntity =null;
	     otpEntity = TestSuite();
	     otpEntity.setUserId(id);
	}

	@Test
	void testGetChannelName() {
		String channel = null;
		otpEntity = null;
		otpEntity = TestSuite();
		channel = otpEntity.getChannelName();
	}

	@Test
	void testSetChannelName() {
		String channel= null;
	    otpEntity =null;
	     otpEntity = TestSuite();
	     otpEntity.setChannelName(channel);
	}

	@Test
	void testOTPEntity() {
		OTPEntity otpEntity= new OTPEntity(1,"shubham@gmail.com",123456);
		assertNotNull(otpEntity);
	}

	@Test
	void testGetEmailId() {
		String email = null;
		otpEntity = null;
		otpEntity = TestSuite();
		email = otpEntity.getEmailId();
	}

	@Test
	void testSetEmailId() {
		String email= null;
	    otpEntity =null;
	     otpEntity = TestSuite();
	     otpEntity.setEmailId(email);
	}

	@Test
	void testGetOtp() {
		Integer otp = 0;
		otpEntity = null;
		otpEntity = TestSuite();
		otp = otpEntity.getOtp();
	}

	@Test
	void testSetOtp() {
		Integer otp= 0;
	    otpEntity =null;
	     otpEntity = TestSuite();
	     otpEntity.setOtp(otp);
	}

	

}
