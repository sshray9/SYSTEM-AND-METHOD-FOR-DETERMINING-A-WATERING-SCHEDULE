package com.shubham.springotp;

import static org.junit.jupiter.api.Assertions.*;

import javax.mail.MessagingException;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.shubham.springotp.controller.OTPController;
import com.shubham.springotp.entity.OTPEntity;
import com.shubham.springotp.service.OTPEmailService;
import com.shubham.springotp.service.OTPServiceImpl;

@SpringBootTest
class OTPControllerTest {

	@InjectMocks
	@Spy
	OTPController otpController;
	
	@Mock
	OTPServiceImpl otpServiceImpl;
	
	@Mock
	OTPEmailService otpEmailService;
	
	@Test
	void testGenerateOTP() throws MessagingException { 
		ResponseEntity<?> otpEntity2= otpController.generateOTP("shubhaaamgupta26@gmail.com", "1", "EMAIL");
		assertNotNull(otpEntity2);
	}

	@Test
	void testValidateOTP() {
		OTPEntity ent = new OTPEntity();
		ent.setEmailId("vimanshu36@gmail.com");
		ent.setOtp(123454);
		ent.setCreationTime(System.currentTimeMillis());
		String res = otpServiceImpl.validateOTP(ent);
		
		assertEquals(null, res);
	}

}
