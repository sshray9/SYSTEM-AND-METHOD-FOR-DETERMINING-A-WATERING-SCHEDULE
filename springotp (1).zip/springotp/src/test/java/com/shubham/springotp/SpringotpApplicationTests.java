package com.shubham.springotp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringotpApplicationTests {

	@Test
	void contextLoads() {
	}

}
