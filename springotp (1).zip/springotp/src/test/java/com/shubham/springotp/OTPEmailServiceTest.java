package com.shubham.springotp;

import static org.junit.jupiter.api.Assertions.*;

import javax.mail.MessagingException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.shubham.springotp.service.OTPEmailService;

@SpringBootTest
class OTPEmailServiceTest {

	@Autowired
	OTPEmailService otpEmailService;
	
	@Test
	void testSendOtpMessage() throws MessagingException {
		int otp=123456;
		String msg="Your OTP is : "+otp+". Valid for 2 mins.";
		otpEmailService.sendOtpMessage("shubhamgupta@gmail.com", "OTP Verification", msg);
		assertEquals("", "");
	}

}
