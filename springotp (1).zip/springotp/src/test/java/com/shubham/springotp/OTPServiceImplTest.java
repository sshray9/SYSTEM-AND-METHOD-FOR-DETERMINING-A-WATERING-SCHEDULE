package com.shubham.springotp;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;

import com.shubham.springotp.dao.OTPDao;
import com.shubham.springotp.entity.OTPEntity;
import com.shubham.springotp.service.OTPServiceImpl;

@SpringBootTest
class OTPServiceImplTest {

	@Mock
	private OTPDao otpDao;

	@Spy
	@InjectMocks
	private OTPServiceImpl otpServiceImpl;

	@Test
	void testGenerateOTP() {
		OTPEntity result = otpServiceImpl.generateOTP("asasa@gmail.com", "EMAIL", 1);
		System.out.println(result);
		assertNotNull(result);
	}

	@Test
	void testValidateOTP() {
		OTPEntity ent = new OTPEntity();
		ent.setEmailId("vimanshu36@gmail.com");
		ent.setOtp(123454);
		ent.setCreationTime(System.currentTimeMillis());
		String res = otpServiceImpl.validateOTP(ent);
		OTPEntity ent1=new OTPEntity();
		ent1.setEmailId("vimanshu36@gmail.com");
		ent1.setOtp(123454);
		String res1=otpServiceImpl.validateOTP(ent1);
		
		assertEquals("User does not exist", res);
		assertEquals("User does not exist", res1);
		
	}

}
